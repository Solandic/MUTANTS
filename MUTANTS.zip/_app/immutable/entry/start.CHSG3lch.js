import{a as t}from"../chunks/entry.B7YO6wG3.js";export{t as start};
